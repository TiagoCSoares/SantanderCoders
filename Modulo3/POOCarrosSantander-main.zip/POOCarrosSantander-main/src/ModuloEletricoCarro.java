public class ModuloEletricoCarro extends ModuloEletrico {
    @Override
    public void ativarModoEco() {

    }

    @Override
    public void carregar(int voltagem) {

    }
}
