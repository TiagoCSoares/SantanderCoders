public abstract class ModuloEletrico {
    public abstract void ativarModoEco();
    public abstract void carregar(int voltagem);
}
