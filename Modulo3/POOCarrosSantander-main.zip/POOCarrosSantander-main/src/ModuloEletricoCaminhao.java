public class ModuloEletricoCaminhao extends ModuloEletrico {
    @Override
    public void ativarModoEco() {

    }

    @Override
    public void carregar(int voltagem) {

    }
}
