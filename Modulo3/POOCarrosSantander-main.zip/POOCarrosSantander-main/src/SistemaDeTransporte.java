public class SistemaDeTransporte {
    public void controleDeCarga(double peso, int distancia) {
        System.out.println("Controlando carga");
    };

    public void calcularRota(String[] pontosDeEntrega) {
        System.out.println("Calculando rota");
    };
}
